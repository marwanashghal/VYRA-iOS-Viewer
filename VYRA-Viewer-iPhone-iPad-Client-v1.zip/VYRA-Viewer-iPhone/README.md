# VYRA Viewer iPhone / iPad Client (v1)

This is the iOS counterpart of the Android mobile/tablet VYRA client.

Included:
- One iPhone + iPad app source
- Landscape only
- Client / viewer only
- Host IP + alphanumeric Room Code + Name join flow
- Movie playback through the same VYRA party session web assets
- Own microphone on/off
- Participants list
- Local mute/unmute per participant only
- No admin moderation (no block / no kick)
- Movie volume + call volume
- Automatic microphone permission request
- Improved VYRA app icon for iPhone/iPad

Build on macOS:
1. Open `VYRAViewerIOS.xcodeproj` in Xcode.
2. Select an iPhone or iPad simulator / device.
3. Signing: set your own Team under the target Signing & Capabilities tab.
4. Build and Run.

Notes:
- iPhone apps cannot programmatically close themselves. The Exit action returns to the app flow instead.
- For the best microphone/WebRTC behavior, test on a real iPhone/iPad device.
