import UIKit
import WebKit
import AVFoundation

final class ViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    private var webView: WKWebView!
    private let tasks = NSMutableDictionary()
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 7
        config.timeoutIntervalForResource = 7
        return URLSession(configuration: config)
    }()
    private var pendingMicState: Bool?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        configureAudioSession()
        configureWebView()
        requestMicrophonePermissionIfNeeded()
        loadApp()
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var shouldAutorotate: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    private func configureAudioSession() {
        let audio = AVAudioSession.sharedInstance()
        try? audio.setCategory(.playAndRecord, options: [.defaultToSpeaker, .allowBluetooth, .mixWithOthers])
        try? audio.setMode(.moviePlayback)
        try? audio.setActive(true)
    }

    private func configureWebView() {
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true
        let controller = WKUserContentController()
        controller.add(self, name: "vyra")
        config.userContentController = controller

        let wv = WKWebView(frame: .zero, configuration: config)
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.translatesAutoresizingMaskIntoConstraints = false
        wv.isOpaque = false
        wv.backgroundColor = .black
        wv.scrollView.isScrollEnabled = false
        if #available(iOS 16.4, *) {
            wv.isInspectable = true
        }
        view.addSubview(wv)
        NSLayoutConstraint.activate([
            wv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            wv.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            wv.topAnchor.constraint(equalTo: view.topAnchor),
            wv.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        webView = wv
    }

    private func requestMicrophonePermissionIfNeeded() {
        let recordPermission = AVAudioSession.sharedInstance().recordPermission
        switch recordPermission {
        case .granted:
            pendingMicState = true
        case .denied:
            pendingMicState = false
        case .undetermined:
            AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    self?.pendingMicState = granted
                    self?.notifyMicPermission(granted)
                }
            }
        @unknown default:
            pendingMicState = false
        }
    }

    private func notifyMicPermission(_ granted: Bool) {
        let js = "window.iosMicPermissionChanged && window.iosMicPermissionChanged(\(granted ? "true" : "false"));"
        webView?.evaluateJavaScript(js, completionHandler: nil)
    }

    private func loadApp() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Resources/www") else {
            return
        }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let granted = pendingMicState { notifyMicPermission(granted) }
    }

    @available(iOS 15.0, *)
    func webView(_ webView: WKWebView,
                 requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo,
                 type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        switch type {
        case .microphone, .cameraAndMicrophone:
            let permission = AVAudioSession.sharedInstance().recordPermission
            if permission == .granted {
                decisionHandler(.grant)
            } else if permission == .denied {
                decisionHandler(.deny)
            } else {
                AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                    DispatchQueue.main.async {
                        self?.pendingMicState = granted
                        self?.notifyMicPermission(granted)
                        decisionHandler(granted ? .grant : .deny)
                    }
                }
            }
        default:
            decisionHandler(.prompt)
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "vyra", let dict = message.body as? [String: Any], let type = dict["type"] as? String else { return }
        switch type {
        case "request":
            handleRequest(dict)
        case "cancel":
            if let id = dict["id"] as? String, let task = tasks[id] as? URLSessionTask {
                task.cancel(); tasks.removeObject(forKey: id)
            }
        case "close":
            dismissOrSuspend()
        default:
            break
        }
    }

    private func handleRequest(_ dict: [String: Any]) {
        guard let id = dict["id"] as? String,
              let urlString = dict["url"] as? String,
              let url = URL(string: urlString) else {
            reply(id: dict["id"] as? String ?? "0", status: 0, body: "", error: "Invalid request.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = (dict["method"] as? String) ?? "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body = dict["body"] as? String {
            request.httpBody = body.data(using: .utf8)
        }

        let task = session.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.tasks.removeObject(forKey: id)
            }
            if let error = error as NSError? {
                if error.domain == NSURLErrorDomain && error.code == NSURLErrorCancelled { return }
                self?.reply(id: id, status: 0, body: "", error: "Cannot reach the host. Check its IP, backend and network.")
                return
            }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let body = String(data: data ?? Data(), encoding: .utf8) ?? ""
            self?.reply(id: id, status: status, body: body, error: nil)
        }
        tasks[id] = task
        task.resume()
    }

    private func reply(id: String, status: Int, body: String, error: String?) {
        let js = "window.iosReply(\(jsonQuoted(id)), \(status), \(jsonQuoted(body)), \(jsonQuoted(error ?? "")));"
        DispatchQueue.main.async { [weak self] in
            self?.webView?.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    private func jsonQuoted(_ string: String) -> String {
        let data = try? JSONSerialization.data(withJSONObject: [string], options: [])
        let json = String(data: data ?? Data("[\"\"]".utf8), encoding: .utf8) ?? "[\"\"]"
        return String(json.dropFirst().dropLast())
    }

    private func dismissOrSuspend() {
        // On iPhone, apps cannot programmatically exit. Return to first screen by background-style reset.
        webView.evaluateJavaScript("window.mobileBack && window.mobileBack();", completionHandler: nil)
    }
}
