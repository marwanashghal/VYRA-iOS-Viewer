"use strict";
let vyraServer = "";
let requestId = 0;
const pendingRequests = new Map();

function normalizeServer(value){
  try {
    const raw = String(value || '').trim();
    const url = new URL(raw);
    if (!/^https?:$/.test(url.protocol)) throw new Error();
    if (!url.hostname) throw new Error();
    url.username = '';
    url.password = '';
    url.search = '';
    url.hash = '';
    if (url.pathname !== '/' && url.pathname !== '') throw new Error();
    return url.origin;
  } catch {
    return '';
  }
}

window.VyraMobile = {
  setServer(value){
    const normalized = normalizeServer(value);
    if (normalized) vyraServer = normalized;
    return normalized;
  },
  close(){
    try{ window.webkit?.messageHandlers?.vyra?.postMessage({ type:'close' }); }catch{}
  }
};

window.iosReply = function(id, status, body, error){
  const p = pendingRequests.get(String(id));
  if(!p) return;
  p.cleanup();
  if(error) p.reject(new Error(error));
  else p.resolve(new Response(body || '', { status: Number(status) || 0 }));
};

window.iosMicPermissionChanged = function(granted){
  if(window.mobileMicPermissionChanged) window.mobileMicPermissionChanged(!!granted);
};

window.fetch = (path, options = {}) => new Promise((resolve, reject) => {
  if(!window.webkit?.messageHandlers?.vyra) {
    reject(new Error('Open the VYRA iPhone app to join.'));
    return;
  }
  const localId = String(++requestId);
  const signal = options.signal;
  const cleanup = () => {
    pendingRequests.delete(localId);
    signal?.removeEventListener('abort', abort);
  };
  const abort = () => {
    try{ window.webkit.messageHandlers.vyra.postMessage({ type:'cancel', id: localId }); }catch{}
    cleanup();
    reject(new DOMException('Request cancelled','AbortError'));
  };
  if(signal?.aborted){
    reject(new DOMException('Request cancelled','AbortError'));
    return;
  }
  const target = vyraServer + String(path || '');
  pendingRequests.set(localId, { resolve, reject, cleanup });
  signal?.addEventListener('abort', abort, { once:true });
  try {
    window.webkit.messageHandlers.vyra.postMessage({
      type:'request',
      id: localId,
      url: target,
      method: String(options.method || 'POST'),
      body: String(options.body || '{}')
    });
  } catch (e) {
    cleanup();
    reject(e);
  }
});

if(!AbortSignal.timeout){
  AbortSignal.timeout = ms => { const c = new AbortController(); setTimeout(() => c.abort(), ms); return c.signal; };
}
if(!AbortSignal.any){
  AbortSignal.any = signals => {
    const c = new AbortController();
    const abort = () => { signals.forEach(s => s.removeEventListener('abort', abort)); c.abort(); };
    if (signals.some(s => s.aborted)) c.abort();
    else signals.forEach(s => s.addEventListener('abort', abort, { once:true }));
    return c.signal;
  };
}
