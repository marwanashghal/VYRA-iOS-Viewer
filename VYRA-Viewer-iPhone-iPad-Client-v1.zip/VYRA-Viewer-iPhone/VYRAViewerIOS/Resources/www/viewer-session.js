(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.VyraSession = api;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';
  class ApiError extends Error {
    constructor(message, status = 0, code = '') {
      super(message); this.name = 'ApiError'; this.status = status; this.code = code;
    }
  }

  async function request(fetcher, path, body, operation, signal) {
    let response;
    try {
      response = await fetcher(path, {
        method: 'POST', cache: 'no-store', signal,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(body)
      });
    } catch (error) {
      if (signal.aborted) throw error;
      throw new ApiError('Cannot reach VYRA. Check that the backend is running and try again.', 0, 'unavailable');
    }
    const raw = await response.text();
    let payload;
    try { payload = JSON.parse(raw); } catch { payload = raw.trim(); }
    const object = payload && typeof payload === 'object' && !Array.isArray(payload);
    let message = typeof payload === 'string' ? payload : (object && (payload.message || payload.detail || payload.error)) || '';
    let code = object ? payload.code || '' : '';
    if (!response.ok) {
      if (response.status === 404 && operation !== 'join' && code !== 'room_closed') {
        code = 'backend_update_required';
        message = 'The backend needs the Viewer session update. Install ViewerSessionController.cs and restart the API.';
      } else if (code === 'room_closed') {
        message = 'This room is no longer available. Ask the host for a new room code.';
      } else if (operation === 'join' && (response.status === 404 || /room not found|invalid room/i.test(message))) {
        code = 'invalid_room'; message = 'Invalid room code. Check the code with your host and try again.';
      } else if (response.status === 403) {
        code = 'participant_blocked'; message = 'The host blocked you from this room. Ask the host to unblock you before joining again.';
      } else if (response.status === 410) {
        code = 'participant_removed'; message = 'You were removed by the host. You can rejoin using the room code.';
      } else if (response.status === 401) {
        code = 'participant_missing'; message = 'Your participation has ended. Please join again.';
      } else if (response.status >= 500 || /no connection|refused/i.test(message)) {
        code = 'unavailable'; message = 'Cannot reach VYRA. Check that the backend is running and try again.';
      } else if (typeof message !== 'string' || !message || message.length > 240 || /[<>\r\n]/.test(message)) {
        message = 'VYRA could not complete this request. Please try again.';
      }
      throw new ApiError(message, response.status, code);
    }
    if (!object) throw new ApiError('VYRA returned an unexpected response. Please restart the backend and try again.', response.status, 'invalid_response');
    return payload;
  }

  class RoomSession {
    constructor({ fetcher, storage, onRoom = () => {}, onEnded = () => {}, onConnection = () => {}, pollMs = 1500, timeoutMs = 8000 }) {
      Object.assign(this, { fetcher, storage, onRoom, onEnded, onConnection, pollMs, timeoutMs });
      this.active = null; this.timer = null; this.controller = null;
      this.joining = false; this.leaving = false;
    }
    async call(path, body, operation, controller = new AbortController()) {
      let timedOut = false;
      const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, this.timeoutMs);
      try { return await request(this.fetcher, path, body, operation, controller.signal); }
      catch (error) {
        if (timedOut) throw new ApiError('VYRA is taking too long to respond. Please try again.', 0, 'unavailable');
        throw error;
      } finally { clearTimeout(timeout); }
    }
    async join(code, name) {
      if (this.active || this.joining || this.leaving) throw new ApiError('Please finish the current room action first.');
      code = code.trim().toUpperCase(); name = name.trim();
      if (!/^[A-Z0-9]{4,12}$/.test(code)) throw new ApiError('Enter a valid room code from your host.');
      if (!name) throw new ApiError('Enter your name to join.');
      this.joining = true;
      try {
        const key = `vyra-participant-token:${code}`;
        const previousToken = this.storage.getItem(key) || '';
        // Verify persistence before creating a new participant on the server.
        this.storage.setItem('vyraViewerName', name);
        const data = await this.call('/api/rooms/join', { roomCode: code, guestName: name, participantToken: previousToken }, 'join');
        if (!data.room || data.room.roomCode !== code || typeof data.participantToken !== 'string' || !data.participantToken)
          throw new ApiError('VYRA did not return a valid room session. Please try again.', 0, 'invalid_response');
        this.storage.setItem(key, data.participantToken);
        const active = { code, name, token: data.participantToken };
        this.active = active;
        this.onRoom(data.room, { id: data.participantId, guestName: name, isMuted: !!data.isMuted });
        this.onConnection('checking', 'Checking your room membership…');
        // Joining is complete once admission succeeds. A slow first status poll
        // must not keep Leave/Join actions locked for another eight seconds.
        this.poll(active);
      } finally { this.joining = false; }
    }
    schedule(active) {
      if (this.active !== active || this.leaving) return;
      clearTimeout(this.timer);
      this.timer = setTimeout(() => this.poll(active), this.pollMs);
    }
    async poll(active = this.active) {
      if (!active || this.active !== active || this.leaving || this.controller) return;
      clearTimeout(this.timer);
      const controller = new AbortController(); this.controller = controller;
      try {
        const data = await this.call(`/api/rooms/${encodeURIComponent(active.code)}/viewer/status`, { participantToken: active.token }, 'status', controller);
        if (this.active !== active || this.leaving) return;
        if (data.sessionProtocolVersion !== 1 || data.room?.roomCode !== active.code || !data.participant)
          throw new ApiError('The backend returned an invalid room status. Please restart the updated API.', 0, 'invalid_response');
        if (data.participant.isBlocked) throw new ApiError('The host blocked you from this room. Ask the host to unblock you before joining again.', 403, 'participant_blocked');
        if (data.participant.isRemoved) throw new ApiError('You were removed by the host. You can rejoin using the room code.', 410, 'participant_removed');
        this.onRoom(data.room, data.participant, data.stream || null);
        this.onConnection('connected', 'Your room membership is up to date.');
      } catch (error) {
        if (this.active !== active || this.leaving || (controller.signal.aborted && error.code !== 'unavailable')) return;
        if (['room_closed', 'participant_blocked', 'participant_removed', 'participant_missing'].includes(error.code))
          this.end(error.message, error.code);
        else this.onConnection('unavailable', error.message || 'Connection lost. Retrying…');
      } finally {
        if (this.controller === controller) this.controller = null;
        this.schedule(active);
      }
    }
    async leave() {
      if (this.joining) throw new ApiError('Finishing your join request. Please try again in a moment.');
      if (!this.active) return;
      if (this.leaving) throw new ApiError('Leaving the room. Please wait.');
      const active = this.active; this.leaving = true;
      clearTimeout(this.timer); this.controller?.abort(); this.controller = null;
      try {
        const data = await this.call(`/api/rooms/${encodeURIComponent(active.code)}/viewer/leave`, { participantToken: active.token }, 'leave');
        if (data.left !== true) throw new ApiError('VYRA could not confirm your departure. Please try again.', 0, 'invalid_response');
        if (this.active === active) this.end('You left the room.', 'left');
      } catch (error) {
        this.onConnection('unavailable', error.message);
        throw error;
      } finally { this.leaving = false; this.schedule(active); }
    }
    end(message, reason) {
      clearTimeout(this.timer); this.timer = null;
      this.controller?.abort(); this.controller = null; this.active = null;
      // Keep the token on Leave, Kick, and Block; never bypass a block with a new token.
      this.onEnded(message, reason);
    }
  }
  return { RoomSession, ApiError, request };
});
