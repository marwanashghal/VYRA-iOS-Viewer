/* Shared Party transport: voice lives for the room; movie tracks can be replaced. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.VyraPartySession=api;})(globalThis,function(){
'use strict';
const PRESETS={auto:{normal:4000000,stereo:8000000},'480p':{normal:2000000,stereo:4000000},'720p':{normal:4000000,stereo:8000000},'1080p':{normal:8000000,stereo:18000000}};
// Feature-detected hints. They request low delay; browsers still enforce their
// own network-dependent minimums. Never seek or resize a received movie.
function lowDelay(receiver,voice=false){
  if(!receiver)return;
  try{if('jitterBufferTarget'in receiver)receiver.jitterBufferTarget=voice?40:0;
      else if('playoutDelayHint'in receiver)receiver.playoutDelayHint=voice?.04:0;}catch{}
}
function preferVideoCodec(transceiver){
  const codecs=globalThis.RTCRtpReceiver?.getCapabilities?.('video')?.codecs;
  if(!transceiver?.setCodecPreferences||!codecs?.some(c=>c.mimeType.toLowerCase()==='video/h264'))return;
  // Prefer the Windows hardware-friendly codec, retaining ALL advertised
  // fallback/repair codecs. No invented H.264 level or SDP modification.
  const rank=c=>({'video/h264':0,'video/vp8':1,'video/vp9':2,'video/av1':3}[c.mimeType.toLowerCase()]??4);
  try{transceiver.setCodecPreferences([...codecs].sort((a,b)=>rank(a)-rank(b)));}catch{}
}
function intervalAverage(now,old,total,count){
  const n=now[count]-old?.[count],value=now[total]-old?.[total];
  return Number.isFinite(n)&&n>0&&Number.isFinite(value)&&value>=0?1000*value/n:null;
}
class Session {
  constructor({base,token,video=null,onStatus=()=>{},onError=()=>{},onPeers=()=>{},onMovie=()=>{},onMic=()=>{},onStats=()=>{},onQuality=()=>{},onAudioBlocked=()=>{},rtcFactory=cfg=>new RTCPeerConnection(cfg),fetcher=(...args)=>fetch(...args),pollMs=550}){
    Object.assign(this,{base,token,video,onStatus,onError,onPeers,onMovie,onMic,onStats,onQuality,onAudioBlocked,rtcFactory,fetcher,pollMs});
    this.peers=new Map();this.localMutes=new Set();this.cursor=0;this.running=false;this.micEnabled=true;this.hostMuted=false;this.quality='auto';this.movie=null;this.source=null;this.voiceVolume=1;this.movieVolume=1;this.epoch=0;
  }
  async request(action,data={},signal=this.controller?.signal){
    const response=await this.fetcher(this.base+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:this.token,generation:this.generation,...data}),signal:signal?AbortSignal.any([signal,AbortSignal.timeout(8000)]):AbortSignal.timeout(8000)});
    const body=await response.json().catch(()=>({}));if(!response.ok){const e=new Error(body.message||body.error||`Party connection failed (${response.status}).`);e.status=response.status;e.code=body.code;throw e;}return body;
  }
  async join(){
    if(this.leaveTask)await this.leaveTask;
    if(this.running)return;this.running=true;this.controller=new AbortController();const epoch=++this.epoch;
    try{const access=await this.request('connect');if(!this.running||epoch!==this.epoch)return;this.id=access.peerId;this.generation=access.generation;this.iceServers=access.iceServers;this.cursor=0;
      this.voiceGroup=new MediaStream();this.movieGroup=new MediaStream();
      this.statsTimer=setInterval(()=>this.sampleStats(),2000);this.statsTimer.unref?.();
      this.onStatus('connecting');this.poll(epoch).catch(e=>{this.onError(e);this.leave();});await this.enableMicrophone();}
    catch(e){if(epoch===this.epoch){this.running=false;this.onError(e);throw e;}}
  }
  async enableMicrophone(){
    if(this.micTrack?.readyState==='ended'){this.micStream?.getTracks().forEach(t=>t.stop());this.micStream=null;this.micTrack=null;}
    if(this.micStream){this.syncMic();return;}
    if(this.micRequest)return this.micRequest;const epoch=this.epoch;
    const request=(async()=>{try{const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});if(!this.running||epoch!==this.epoch){stream.getTracks().forEach(t=>t.stop());return;}this.micStream=stream;this.micTrack=stream.getAudioTracks()[0];this.syncMic();await Promise.all([...this.peers.values()].map(p=>p.voice?.sender.replaceTrack(this.micTrack)));}
    catch(e){const messages={NotAllowedError:'Allow microphone access in Android app settings, then tap Mic to retry.',NotFoundError:'No microphone detected. Check your connected headset.',NotReadableError:'Microphone could not start. Check Android microphone access and close other recording apps.',SecurityError:'Microphone access was blocked. Update Android System WebView.'};this.onMic({available:false,enabled:false,blocked:this.hostMuted,message:messages[e.name]||'Microphone unavailable ('+(e.name||'unknown error')+'). Tap Mic to retry.'});}})();
    this.micRequest=request;try{await request;}finally{if(this.micRequest===request)this.micRequest=null;}
  }
  syncMic(){if(this.micTrack)this.micTrack.enabled=this.micEnabled&&!this.hostMuted;this.onMic({available:!!this.micTrack,enabled:!!this.micTrack?.enabled,blocked:this.hostMuted});}
  async setMic(enabled){this.micEnabled=!!enabled;if(enabled&&(!this.micTrack||this.micTrack.readyState==='ended'))await this.enableMicrophone();this.syncMic();}
  async poll(epoch){
    while(this.running&&epoch===this.epoch){
      try{const data=await this.request('poll',{after:this.cursor});if(!this.running||epoch!==this.epoch)return;
        this.cursor=data.cursor;const roster=data.peers||[];const me=roster.find(p=>p.id===this.id);this.hostMuted=!!me?.muted;this.syncMic();
        for(const [id,p] of this.peers){const info=roster.find(x=>x.id===id);if(!info||info.generation!==p.info.generation)this.drop(id);}
        for(const info of roster.filter(p=>p.id!==this.id)){
          let peer=this.peers.get(info.id);if(!peer)peer=await this.add(info);peer.info=info;if(peer.audio)peer.audio.muted=!!info.muted||this.localMutes.has(info.id);
        }
        const key=JSON.stringify(data.movie);if(this.movieKey!==key){this.movieKey=key;this.movie=data.movie||null;this.onMovie(this.movie);}
        for(const s of data.signals||[]){try{await this.receive(s);}catch(e){this.onError(e);}}
        this.maxViewers=data.maxViewers||4;this.roster=roster;this.reportPeers();
        this.onStatus(this.peers.size?[...this.peers.values()].some(p=>p.pc.connectionState==='connected')?'connected':'connecting':'ready');
      }catch(e){if(!this.running||epoch!==this.epoch)return;if([401,403,410].includes(e.status)){this.onStatus('ended');this.onError(e);await this.leave();return;}this.onStatus('reconnecting');if(e.code==='peer_expired'){for(const id of [...this.peers.keys()])this.drop(id);const access=await this.request('connect');this.generation=access.generation;this.cursor=0;}else this.onError(e);}
      await new Promise(resolve=>setTimeout(resolve,this.pollMs));
    }
  }
  async add(info){
    const pc=this.rtcFactory({iceServers:this.iceServers,bundlePolicy:'max-bundle'});const p={pc,info,candidates:[],quality:this.quality,offerer:Number(this.id)<Number(info.id),closed:false,tuning:Promise.resolve(),stats:new Map()};this.peers.set(info.id,p);
    pc.onicecandidate=e=>{if(e.candidate&&this.running)this.signal(info.id,{kind:'candidate',candidate:e.candidate.toJSON?.()||e.candidate}).catch(e=>this.onError(e));};
    pc.onconnectionstatechange=()=>{if(pc.connectionState==='failed'){if(p.offerer&&this.running&&!p.restarted){p.restarted=true;pc.restartIce();this.offer(p).catch(e=>this.onError(e));}this.onError(new Error(`Connection to ${info.name} failed. Check the server's TURN/network settings.`));}if(pc.connectionState==='connected')this.onStatus('connected');};
    pc.ontrack=e=>this.track(p,e);
    if(p.offerer){
      p.voice=pc.addTransceiver('audio',{direction:'sendrecv',streams:[this.voiceGroup]});if(this.micTrack)await p.voice.sender.replaceTrack(this.micTrack);
      if(this.id==='0'){p.video=pc.addTransceiver('video',{direction:'sendonly',streams:[this.movieGroup]});p.movieAudio=pc.addTransceiver('audio',{direction:'sendonly',streams:[this.movieGroup]});preferVideoCodec(p.video);if(this.source){await p.video.sender.replaceTrack(this.source.videoTrack);await p.movieAudio.sender.replaceTrack(this.source.audioTrack);}}
      await this.offer(p);
    }
    return p;
  }
  async offer(p){if(p.closed)return;if(p.pc.signalingState!=='stable'){p.offerPending=true;return;}p.offerPending=false;await p.pc.setLocalDescription(await p.pc.createOffer());await this.signal(p.info.id,{kind:'description',description:p.pc.localDescription});}
  signal(to,payload){const peer=this.peers.get(to);if(!this.running||!peer||peer.closed)return Promise.resolve();return this.request('signal',{to,targetGeneration:peer.info.generation,payload});}
  async receive({from,generation,payload}){
    const p=this.peers.get(from);if(!p||p.closed||generation!==p.info.generation)return;const pc=p.pc;
    if(payload.kind==='description'){
      await pc.setRemoteDescription(payload.description);
      const ts=pc.getTransceivers();p.voice=ts[0];if(this.id!=='0'&&from==='0'){p.video=ts[1];p.movieAudio=ts[2];}
      if(p.voice){p.voice.direction='sendrecv';p.voice.sender.setStreams?.(this.voiceGroup);await p.voice.sender.replaceTrack(this.micTrack||null);lowDelay(p.voice.receiver,true);}
      if(p.video){lowDelay(p.video.receiver);preferVideoCodec(p.video);}if(p.movieAudio)lowDelay(p.movieAudio.receiver);
      for(const candidate of p.candidates.splice(0))await pc.addIceCandidate(candidate);
      if(payload.description.type==='offer'){await pc.setLocalDescription(await pc.createAnswer());await this.signal(from,{kind:'description',description:pc.localDescription});if(from==='0')await this.signal('0',{kind:'quality',quality:this.quality});}
      else if(p.offerPending)await this.offer(p);
      await this.applyQuality(p);
    }else if(payload.kind==='candidate'){if(pc.remoteDescription)await pc.addIceCandidate(payload.candidate);else p.candidates.push(payload.candidate);}
    else if(payload.kind==='quality'&&this.id==='0'&&PRESETS[payload.quality]){p.quality=payload.quality;p.autoBitrate=null;p.goodSamples=0;await this.applyQuality(p);}
    else if(payload.kind==='quality-applied'&&from==='0'&&payload.quality===this.quality&&Number.isFinite(payload.bitrate))this.onQuality({quality:payload.quality,bitrate:payload.bitrate,pending:false});
  }
  track(p,event){
    const index=p.pc.getTransceivers().indexOf(event.transceiver);
    lowDelay(event.receiver||event.transceiver?.receiver,index===0);
    if(index===0){
      if(p.audio)p.audio.remove();const audio=document.createElement('audio');audio.autoplay=true;audio.hidden=true;audio.dataset.partyVoice=p.info.id;audio.srcObject=new MediaStream([event.track]);audio.volume=this.voiceVolume;audio.muted=!!p.info.muted||this.localMutes.has(p.info.id);document.body.appendChild(audio);p.audio=audio;audio.play().catch(()=>this.onAudioBlocked());
    }else if(this.video&&p.info.id==='0'){
      if(!this.remoteMovie)this.remoteMovie=new MediaStream();
      for(const old of this.remoteMovie.getTracks())if(old.kind===event.track.kind&&old!==event.track)this.remoteMovie.removeTrack(old);
      if(!this.remoteMovie.getTracks().includes(event.track))this.remoteMovie.addTrack(event.track);
      if(this.video.srcObject!==this.remoteMovie)this.video.srcObject=this.remoteMovie;
      this.video.muted=false;this.video.volume=this.movieVolume;this.video.play().catch(()=>this.onAudioBlocked());
    }
  }
  setVoiceVolume(value){this.voiceVolume=Math.max(0,Math.min(1,value));for(const p of this.peers.values())if(p.audio)p.audio.volume=this.voiceVolume;}
  reportPeers(){this.onPeers((this.roster||[]).map(p=>({...p,isSelf:p.id===this.id,locallyMuted:this.localMutes.has(p.id),connection:p.id===this.id?'local':this.peers.get(p.id)?.pc.connectionState||'connecting'})),this.maxViewers||4);}
  setPeerMuted(id,muted){id=String(id);if(id===this.id)return;muted?this.localMutes.add(id):this.localMutes.delete(id);const p=this.peers.get(id);if(p?.audio)p.audio.muted=!!p.info.muted||!!muted;this.reportPeers();}
  setMovieVolume(value){this.movieVolume=Math.max(0,Math.min(1,value));if(this.video)this.video.volume=this.movieVolume;}
  async resumeAudio(){await Promise.all([...this.peers.values()].filter(p=>p.audio).map(p=>p.audio.play()));if(this.video?.srcObject)await this.video.play();}
  applyQuality(p){
    // Quality changes/movie replacement may overlap. Serialize parameter writes
    // so a stale transaction cannot silently lose the resolution policy.
    p.tuning=p.tuning.catch(()=>{}).then(async()=>{
      if(p.closed)return;const preset=PRESETS[p.quality]||PRESETS['1080p'];
      for(const [transceiver,values,priority] of [
        [p.voice,{maxBitrate:48000},'high'],
        [p.movieAudio,{maxBitrate:192000},'medium'],
        [p.video,{maxBitrate:p.quality==='auto'?(p.autoBitrate||(this.source?.mode==='full-sbs'?preset.stereo:preset.normal)):(this.source?.mode==='full-sbs'?preset.stereo:preset.normal),scaleResolutionDownBy:1,maxFramerate:30},'low']]){
        if(!transceiver||p.closed)continue;const sender=transceiver.sender,params=sender.getParameters();if(!params.encodings?.length)continue;
        if(transceiver===p.video)params.degradationPreference='maintain-resolution';
        for(const encoding of params.encodings)Object.assign(encoding,values,{priority,networkPriority:priority});
        try{await sender.setParameters(params);}catch(e){
          if(p.closed)return;
          if(!['NotSupportedError','TypeError'].includes(e.name))throw e;
          // Older WebView2 builds may reject optional priority extensions.
          const basic=sender.getParameters();if(transceiver===p.video)basic.degradationPreference='maintain-resolution';
          for(const encoding of basic.encodings||[]){delete encoding.priority;delete encoding.networkPriority;Object.assign(encoding,values);}
          await sender.setParameters(basic);
        }
      }
      if(this.id==='0'&&p.video&&!p.closed){
        const applied=p.video.sender.getParameters().encodings?.[0];
        if(applied?.maxBitrate&&applied.scaleResolutionDownBy===1)
          await this.signal(p.info.id,{kind:'quality-applied',quality:p.quality,bitrate:applied.maxBitrate});
      }
    });return p.tuning;
  }
  async sampleStats(){
    if(!this.running||this.sampling)return;this.sampling=true;const epoch=this.epoch;
    try{for(const p of this.peers.values()){
      if(p.closed||!p.pc.getStats)continue;
      const report=await p.pc.getStats();if(!this.running||epoch!==this.epoch)return;
      const stats=[...report.values()],rows=[];
      for(const s of stats){
        if(!['inbound-rtp','outbound-rtp'].includes(s.type)||s.isRemote)continue;
        const previous=p.stats.get(s.id),codec=report.get(s.codecId),seconds=(s.timestamp-previous?.timestamp)/1000;
        const frameCount=s.type==='inbound-rtp'?'framesDecoded':'framesEncoded';
        const bytes=s.type==='inbound-rtp'?'bytesReceived':'bytesSent';
        rows.push({direction:s.type,kind:s.kind||s.mediaType,codec:codec?.mimeType,mid:s.mid,width:s.frameWidth,height:s.frameHeight,
          mbps:seconds>0&&Number.isFinite(s[bytes]-previous?.[bytes])?Math.max(0,8*(s[bytes]-previous[bytes])/seconds/1000000):null,
          fps:Number.isFinite(s.framesPerSecond)?s.framesPerSecond:seconds>0&&Number.isFinite(s[frameCount]-previous?.[frameCount])?Math.max(0,(s[frameCount]-previous[frameCount])/seconds):null,
          bufferMs:intervalAverage(s,previous,'jitterBufferDelay','jitterBufferEmittedCount'),
          queueMs:intervalAverage(s,previous,'totalPacketSendDelay','packetsSent'),
          encodeMs:intervalAverage(s,previous,'totalEncodeTime','framesEncoded'),limitation:s.qualityLimitationReason});
        p.stats.set(s.id,s);
      }
      const transport=stats.find(s=>s.type==='transport'&&s.selectedCandidatePairId),pair=report.get(transport?.selectedCandidatePairId);
      if(this.id==='0'&&p.quality==='auto'&&this.source&&p.video)await this.adaptAuto(p,rows,pair);
      this.onStats({peerId:p.info.id,rows,rttMs:Number.isFinite(pair?.currentRoundTripTime)?pair.currentRoundTripTime*1000:null});
    }}catch{/* Stats are diagnostic; unsupported fields must never end the call. */}finally{this.sampling=false;}
  }
  async adaptAuto(p,rows,pair){
    const video=rows.find(s=>s.kind==='video'&&s.direction==='outbound-rtp');if(!video)return;
    const stereo=this.source?.mode==='full-sbs',initial=stereo?PRESETS.auto.stereo:PRESETS.auto.normal,ceiling=stereo?PRESETS['1080p'].stereo:PRESETS['1080p'].normal,floor=stereo?1000000:500000;
    const current=p.autoBitrate||initial;
    const available=pair?.availableOutgoingBitrate;
    const networkCap=Number.isFinite(available)&&available>0?Math.max(floor,(available-240000)*.8):ceiling;
    const pressured=video.queueMs>100||video.encodeMs>40||video.limitation==='cpu'||video.limitation==='bandwidth';
    let next=current;
    if(pressured||networkCap<current*.9){next=Math.min(current*.75,networkCap);p.goodSamples=0;}
    else if(++p.goodSamples>=3){next=Math.min(current*1.1,networkCap);p.goodSamples=0;}
    next=Math.round(Math.max(floor,Math.min(ceiling,next)));
    if(Math.abs(next-current)>=50000){p.autoBitrate=next;await this.applyQuality(p);}
  }
  async setQuality(quality){if(!PRESETS[quality])throw new Error('Unknown bandwidth preset.');this.quality=quality;this.onQuality({quality,pending:true});if(this.running&&this.peers.has('0'))await this.signal('0',{kind:'quality',quality});}
  async setMovie(source,descriptor){
    if(this.id!=='0')throw new Error('Only the host can publish a movie.');
    if(source){const s=source.videoTrack.getSettings();if(s.width!==descriptor.width||s.height!==descriptor.height)throw new Error(`Source is ${s.width}×${s.height}; expected ${descriptor.width}×${descriptor.height}.`);source.videoTrack.contentHint='detail';}
    this.source=source;
    for(const p of this.peers.values())if(p.video){p.autoBitrate=null;p.goodSamples=0;p.stats.clear();await p.video.sender.replaceTrack(source?.videoTrack||null);await p.movieAudio.sender.replaceTrack(source?.audioTrack||null);await this.applyQuality(p);}
    await this.request('state',{movie:descriptor||null});this.movie=descriptor||null;
  }
  updateOptions(options){return this.request('state',options);}
  drop(id){const p=this.peers.get(id);if(!p)return;p.closed=true;p.pc.close();p.audio?.remove();this.peers.delete(id);if(id==='0'&&this.video){this.video.srcObject=null;this.remoteMovie=null;}}
  leave(){if(this.leaveTask)return this.leaveTask;this.leaveTask=this.closeSession().finally(()=>{this.leaveTask=null;});return this.leaveTask;}
  async closeSession(){
    if(!this.running&&!this.controller)return;this.running=false;this.epoch++;clearInterval(this.statsTimer);this.statsTimer=null;
    // Local audio stops immediately, even if the backend is unreachable.
    this.micStream?.getTracks().forEach(t=>t.stop());this.micStream=null;this.micTrack=null;this.micRequest=null;
    for(const id of [...this.peers.keys()])this.drop(id);
    try{await this.request('leave',{},null);}catch{}this.controller?.abort();this.controller=null;this.cursor=0;this.movie=null;this.movieKey=undefined;this.source=null;this.roster=[];this.onStatus('ended');
  }
}
return {Session,PRESETS};
});
